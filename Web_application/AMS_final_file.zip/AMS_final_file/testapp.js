const express = require("express");
const cors = require('cors');
const mssql = require('mssql');
const nodeMailer = require('nodemailer');
let moment = require('moment');
let app = express();

app.use(express.urlencoded({extended:false}));
app.use(
    cors({
        origin : '*',
        methods : ['GET', 'POST', 'PUT', 'DELETE'],
        allowHeaders : ['Content-Type']
    })
);

const sqlConfig = {
    server : '10.0.175.122',
    user : 'SA',
    password : 'Soulsvciot01',
    database : 'asset',

    options: {
        encrypt : false,
        trustServerCertificate : false
    }
}

mssql.connect(sqlConfig, (err, result)=>{
    if(err) throw err
    else{
       sqlQuery();   
    }
})

function sqlQuery(){
    // let q = `SELECT user_type FROM Users WHERE user_id = '1' AND email = 'user@user.com'`;
    // let q = `SELECT * FROM Activity INNER JOIN assets ON assets.tag_id=Activity.tag_id where asset_id='180000005471'`;
    let q = `SELECT tag_id FROM assets WHERE asset_id = '180000005471'`;
    let queryResult = mssql.query(q, (err, result)=>{
        if(err) throw err
        else{
            console.log(result.recordset[0].tag_id);
        }
    });
}